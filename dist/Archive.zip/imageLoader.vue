<template>
    <v-row class="fill-height ma-0" align="center" justify="center">
      <v-progress-circular indeterminate color="#ff6200"></v-progress-circular>
    </v-row>
  </template>